#include "proflame2_cc1101.h"
#include "esphome/core/log.h"
#include "esphome/core/helpers.h"

namespace esphome {
namespace proflame2 {

static const char *TAG = "proflame2";

// CC1101 Configuration for 314.973 MHz OOK at 2400 baud
// These values are calculated for 26MHz crystal
static const uint8_t CC1101_CONFIG[][2] = {
    {CC1101_IOCFG0,   0x06},  // GDO0 Output Pin Configuration
    {CC1101_FIFOTHR,  0x47},  // RX FIFO and TX FIFO Thresholds
    {CC1101_PKTCTRL0, 0x32},  // Packet Automation Control - Async serial mode
    {CC1101_FSCTRL1,  0x06},  // Frequency Synthesizer Control
    {CC1101_FREQ2,    0x0C},  // Frequency Control Word, High Byte (314.973 MHz)
    {CC1101_FREQ1,    0x1D},  // Frequency Control Word, Middle Byte
    {CC1101_FREQ0,    0x89},  // Frequency Control Word, Low Byte
    {CC1101_MDMCFG4,  0x87},  // Modem Configuration - 2400 baud
    {CC1101_MDMCFG3,  0x32},  // Modem Configuration
    {CC1101_MDMCFG2,  0x30},  // Modem Configuration - OOK, no sync
    {CC1101_MDMCFG1,  0x00},  // Modem Configuration
    {CC1101_MDMCFG0,  0xF8},  // Modem Configuration
    {CC1101_DEVIATN,  0x00},  // Modem Deviation Setting (not used for OOK)
};

void ProFlame2Component::setup() {
    ESP_LOGCONFIG(TAG, "Setting up ProFlame 2 CC1101...");
    
    this->spi_setup();
    
    if (this->gdo0_pin_ != nullptr) {
        this->gdo0_pin_->setup();
        this->gdo0_pin_->pin_mode(gpio::FLAG_INPUT);
    }
    
    // Reset and configure CC1101
    this->reset_cc1101();
    delay(10);
    this->configure_cc1101();
    
    // Initialize state
    this->current_state_ = ProFlame2Command{
        .pilot_cpi = false,
        .light_level = 0,
        .thermostat = false,
        .power = false,
        .front_flame = false,
        .fan_level = 0,
        .aux_power = false,
        .flame_level = 0
    };
    
    ESP_LOGCONFIG(TAG, "ProFlame 2 setup complete");
}

void ProFlame2Component::loop() {
    // Rate limiting is handled in transmit_command()
}

void ProFlame2Component::dump_config() {
    ESP_LOGCONFIG(TAG, "ProFlame 2 CC1101:");
    ESP_LOGCONFIG(TAG, "  Serial Number: 0x%08X", this->serial_number_);
    if (this->gdo0_pin_ != nullptr) {
        LOG_PIN("  GDO0 Pin: ", this->gdo0_pin_);
    }
}

void ProFlame2Component::write_register(uint8_t reg, uint8_t value) {
    this->enable();
    this->write_byte(reg);
    this->write_byte(value);
    this->disable();
}

uint8_t ProFlame2Component::read_register(uint8_t reg) {
    this->enable();
    this->write_byte(reg | 0x80);  // Read flag
    uint8_t value = this->read_byte();
    this->disable();
    return value;
}

void ProFlame2Component::send_strobe(uint8_t strobe) {
    this->enable();
    this->write_byte(strobe);
    this->disable();
}

void ProFlame2Component::reset_cc1101() {
    this->enable();
    delayMicroseconds(10);
    this->disable();
    delayMicroseconds(40);
    this->send_strobe(CC1101_SRES);
    delay(1);
}

void ProFlame2Component::configure_cc1101() {
    // Write configuration registers
    for (size_t i = 0; i < sizeof(CC1101_CONFIG) / sizeof(CC1101_CONFIG[0]); i++) {
        this->write_register(CC1101_CONFIG[i][0], CC1101_CONFIG[i][1]);
    }
    
    // Set to IDLE state
    this->send_strobe(CC1101_SIDLE);
    
    // Flush FIFOs
    this->send_strobe(0x3A);  // SFTX
    this->send_strobe(0x3B);  // SFRX
    
    ESP_LOGD(TAG, "CC1101 configured for 314.973 MHz OOK at 2400 baud");
}

uint8_t ProFlame2Component::calculate_parity(uint16_t data) {
    // Count number of 1s in the data (including padding bit)
    uint8_t ones = 0;
    for (int i = 0; i < 9; i++) {
        if (data & (1 << i)) ones++;
    }
    // Return 1 if odd number of ones, 0 if even
    return ones & 1;
}

uint8_t ProFlame2Component::calculate_checksum(uint8_t cmd_byte, uint8_t c_const, uint8_t d_const) {
    uint8_t high_nibble = (cmd_byte >> 4) & 0x0F;
    uint8_t low_nibble = cmd_byte & 0x0F;
    
    uint8_t x = (c_const ^ (high_nibble << 1) ^ high_nibble ^ (low_nibble << 1)) & 0x0F;
    uint8_t y = (d_const ^ high_nibble ^ low_nibble) & 0x0F;
    
    return (x << 4) | y;
}

void ProFlame2Component::build_packet(uint8_t *packet) {
    // Clear packet buffer (91 bits = 12 bytes)
    memset(packet, 0, 12);
    
    // Extract serial number words (assuming serial is 24 bits)
    uint16_t serial1 = (this->serial_number_ >> 16) & 0xFF;
    uint16_t serial2 = (this->serial_number_ >> 8) & 0xFF;
    uint16_t serial3 = this->serial_number_ & 0xFF;
    
    // Build command bytes
    uint8_t cmd1 = (this->current_state_.pilot_cpi ? 0x80 : 0x00) |
                   ((this->current_state_.light_level & 0x07) << 4) |
                   (this->current_state_.thermostat ? 0x02 : 0x00) |
                   (this->current_state_.power ? 0x01 : 0x00);
    
    uint8_t cmd2 = (this->current_state_.front_flame ? 0x80 : 0x00) |
                   ((this->current_state_.fan_level & 0x07) << 4) |
                   (this->current_state_.aux_power ? 0x08 : 0x00) |
                   (this->current_state_.flame_level & 0x07);
    
    // Calculate checksums
    uint8_t checksum1 = this->calculate_checksum(cmd1, 0x0D, 0x00);  // C=0b1101, D=0
    uint8_t checksum2 = this->calculate_checksum(cmd2, 0x00, 0x07);  // C=0, D=0b0111
    
    // Build 7 words of 13 bits each
    // Word format: S(1) | Guard(1) | Data(8) | Padding(1) | Parity(1) | Guard(1)
    // S is handled in Manchester encoding as sync pattern
    
    uint16_t words[7];
    
    // Serial words (first word has padding bit = 1, others = 0)
    words[0] = 0x1000 | (serial1 << 3) | 0x200 | (calculate_parity(serial1 | 0x100) << 1) | 0x01;
    words[1] = 0x1000 | (serial2 << 3) | (calculate_parity(serial2) << 1) | 0x01;
    words[2] = 0x1000 | (serial3 << 3) | (calculate_parity(serial3) << 1) | 0x01;
    
    // Command words
    words[3] = 0x1000 | (cmd1 << 3) | (calculate_parity(cmd1) << 1) | 0x01;
    words[4] = 0x1000 | (cmd2 << 3) | (calculate_parity(cmd2) << 1) | 0x01;
    
    // Checksum words
    words[5] = 0x1000 | (checksum1 << 3) | (calculate_parity(checksum1) << 1) | 0x01;
    words[6] = 0x1000 | (checksum2 << 3) | (calculate_parity(checksum2) << 1) | 0x01;
    
    // Pack words into bit array (91 bits total)
    int bit_index = 0;
    for (int w = 0; w < 7; w++) {
        for (int b = 12; b >= 0; b--) {
            int byte_index = bit_index / 8;
            int bit_offset = 7 - (bit_index % 8);
            if (words[w] & (1 << b)) {
                packet[byte_index] |= (1 << bit_offset);
            }
            bit_index++;
        }
    }
}

void ProFlame2Component::encode_manchester(uint8_t *input, uint8_t *output, size_t input_bits) {
    // Thomas Manchester encoding:
    // 0 -> 01
    // 1 -> 10
    // Sync (S) -> 11
    // Padding (Z) -> 00
    
    int out_index = 0;
    memset(output, 0, 46);  // 182 bits = 23 bytes
    
    for (size_t i = 0; i < input_bits; i++) {
        int byte_index = i / 8;
        int bit_offset = 7 - (i % 8);
        bool bit = (input[byte_index] >> bit_offset) & 1;
        
        // Check if this is a sync position (every 13 bits, at position 0)
        bool is_sync = (i % 13) == 0;
        
        int out_byte = out_index / 8;
        int out_bit = 7 - (out_index % 8);
        
        if (is_sync) {
            // Sync pattern: 11
            output[out_byte] |= (1 << out_bit);
            out_index++;
            out_bit = 7 - (out_index % 8);
            if (out_bit == 7) out_byte++;
            output[out_byte] |= (1 << out_bit);
        } else if (bit) {
            // 1 -> 10
            output[out_byte] |= (1 << out_bit);
            out_index++;
            // Second bit is 0, already cleared
        } else {
            // 0 -> 01
            // First bit is 0, already cleared
            out_index++;
            out_bit = 7 - (out_index % 8);
            if (out_bit == 7) out_byte++;
            output[out_byte] |= (1 << out_bit);
        }
        out_index++;
    }
}

void ProFlame2Component::transmit_command() {
    // Rate limiting
    uint32_t now = millis();
    if (now - this->last_transmission_ < MIN_TRANSMISSION_INTERVAL) {
        return;
    }
    
    ESP_LOGD(TAG, "Transmitting command - Power:%d, Flame:%d, Fan:%d, Light:%d", 
             this->current_state_.power, 
             this->current_state_.flame_level,
             this->current_state_.fan_level,
             this->current_state_.light_level);
    
    // Build packet
    uint8_t packet[12];  // 91 bits
    this->build_packet(packet);
    
    // Encode with Manchester encoding
    uint8_t encoded[46];  // 182 bits
    this->encode_manchester(packet, encoded, 91);
    
    // Prepare transmission buffer with 5 repetitions
    // Each repetition is 182 bits + 12 zero bits separator = 194 bits
    // Total: 970 bits = 122 bytes
    uint8_t tx_buffer[150];
    memset(tx_buffer, 0, sizeof(tx_buffer));
    
    int buffer_pos = 0;
    for (int rep = 0; rep < 5; rep++) {
        // Copy encoded packet
        for (int i = 0; i < 23; i++) {
            tx_buffer[buffer_pos++] = encoded[i];
        }
        // Add 12 zero bits (1.5 bytes) separator
        buffer_pos += 2;
    }
    
    // Enter TX mode
    this->send_strobe(CC1101_STX);
    
    // Send data via SPI FIFO
    this->enable();
    this->write_byte(0x7F);  // Burst write to TX FIFO
    for (int i = 0; i < buffer_pos; i++) {
        this->write_byte(tx_buffer[i]);
    }
    this->disable();
    
    // Wait for transmission to complete
    delay(50);  // ~400ms at 2400 baud for complete burst
    
    // Return to IDLE
    this->send_strobe(CC1101_SIDLE);
    
    this->last_transmission_ = now;
}

// Control method implementations
void ProFlame2Component::set_power(bool state) {
    if (this->current_state_.power != state) {
        this->current_state_.power = state;
        this->transmit_command();
        if (this->power_switch_) {
            this->power_switch_->publish_state(state);
        }
        ESP_LOGI(TAG, "Power set to %s", state ? "ON" : "OFF");
    }
}

void ProFlame2Component::set_pilot_mode(bool cpi_mode) {
    if (this->current_state_.pilot_cpi != cpi_mode) {
        this->current_state_.pilot_cpi = cpi_mode;
        this->transmit_command();
        if (this->pilot_switch_) {
            this->pilot_switch_->publish_state(cpi_mode);
        }
        ESP_LOGI(TAG, "Pilot mode set to %s", cpi_mode ? "CPI" : "IPI");
    }
}

void ProFlame2Component::set_flame_level(uint8_t level) {
    if (level > 6) level = 6;
    if (this->current_state_.flame_level != level) {
        this->current_state_.flame_level = level;
        this->transmit_command();
        if (this->flame_number_) {
            this->flame_number_->publish_state(level);
        }
        ESP_LOGI(TAG, "Flame level set to %d", level);
    }
}

void ProFlame2Component::set_fan_level(uint8_t level) {
    if (level > 6) level = 6;
    if (this->current_state_.fan_level != level) {
        this->current_state_.fan_level = level;
        this->transmit_command();
        if (this->fan_number_) {
            this->fan_number_->publish_state(level);
        }
        ESP_LOGI(TAG, "Fan level set to %d", level);
    }
}

void ProFlame2Component::set_light_level(uint8_t level) {
    if (level > 6) level = 6;
    if (this->current_state_.light_level != level) {
        this->current_state_.light_level = level;
        this->transmit_command();
        if (this->light_number_) {
            this->light_number_->publish_state(level);
        }
        ESP_LOGI(TAG, "Light level set to %d", level);
    }
}

void ProFlame2Component::set_aux_power(bool state) {
    if (this->current_state_.aux_power != state) {
        this->current_state_.aux_power = state;
        this->transmit_command();
        if (this->aux_switch_) {
            this->aux_switch_->publish_state(state);
        }
        ESP_LOGI(TAG, "Aux power set to %s", state ? "ON" : "OFF");
    }
}

void ProFlame2Component::set_front_flame(bool state) {
    if (this->current_state_.front_flame != state) {
        this->current_state_.front_flame = state;
        this->transmit_command();
        if (this->front_switch_) {
            this->front_switch_->publish_state(state);
        }
        ESP_LOGI(TAG, "Front flame set to %s", state ? "ON" : "OFF");
    }
}

void ProFlame2Component::set_thermostat(bool state) {
    if (this->current_state_.thermostat != state) {
        this->current_state_.thermostat = state;
        this->transmit_command();
        if (this->thermostat_switch_) {
            this->thermostat_switch_->publish_state(state);
        }
        ESP_LOGI(TAG, "Thermostat set to %s", state ? "ON" : "OFF");
    }
}

}  // namespace proflame2
}  // namespace esphome
